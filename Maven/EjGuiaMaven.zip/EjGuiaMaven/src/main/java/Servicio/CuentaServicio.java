package Servicio;

import com.mycompany.ejguiamaven.Entidad.Cuenta;
import com.mycompany.ejguiamaven.Entidad.Usuario;
import java.util.ArrayList;

public class CuentaServicio {

    ArrayList<Cuenta> listaCuentas = new ArrayList();

    public void crearCuenta(Usuario u) {
        int numCuenta = (int) (Math.random() * 100);
        Cuenta c = new Cuenta(u, 0, numCuenta);
        listaCuentas.add(c);
        System.out.println("Su numero de cuenta es "+ c.getNumCuenta());

    }

    public void depositar(int numCuenta, double monto) {
        for (Cuenta c : listaCuentas) {
            if (c.getNumCuenta() == numCuenta) {
                c.setSaldo(monto + c.getSaldo());
                System.out.println("Se deposito en la cuenta " + monto);
                System.out.println("Su saldo actual es " + c.getSaldo());
            }
        }
    }

    public void retirar(int numCuenta, double monto) {
        for (Cuenta c : listaCuentas) {
            if (c.getNumCuenta() == numCuenta) {
                if (monto <= c.getSaldo()) {
                    c.setSaldo(c.getSaldo() - monto);
                } else {
                    System.out.println("Saldo insuficiente");
                }
            }
        }
    }

    public void tranferencia(int numCuenta1, int numCuenta2, double monto) {

        for (Cuenta c : listaCuentas) {
            if (c.getNumCuenta() == numCuenta1) {
                for (Cuenta cuenta : listaCuentas) {
                    if (cuenta.getNumCuenta() == numCuenta2) {
                        if (monto <= c.getSaldo()) {
                            c.setSaldo(c.getSaldo() - monto);
                            cuenta.setSaldo(monto+cuenta.getSaldo());
                            System.out.println("Saldo disponible "+c.getSaldo());

                        }
                    }
                }

            }
        }
    }
}
