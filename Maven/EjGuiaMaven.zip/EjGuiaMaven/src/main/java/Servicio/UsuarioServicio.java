
package Servicio;

import com.mycompany.ejguiamaven.Entidad.Usuario;
import java.util.ArrayList;
import java.util.Scanner;


public class UsuarioServicio {
    ArrayList<Usuario> listaUsuarios = new ArrayList();
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    
    
    public Usuario ingresar(String contrasena, String nombreUsuario){
        for (Usuario u : listaUsuarios ) {
            if (u.getNombreUsuario().equalsIgnoreCase(nombreUsuario)) {
                if (u.getContrasena().equals(contrasena)) {
                    return u;
                }else{
                    System.out.println("Contraseña incorrecta");
                    break;
                }
            }
        }
        return null;
    }
    
    public void crearUsuario(){
        System.out.println("Ingrese el nombre de usuario");
        String nombre = leer.next();
        System.out.println("Ingrese contraseña");
        String contrasena = leer.next();
        Usuario u =new Usuario(false, nombre, contrasena);
        listaUsuarios.add(u);
        
    }
    public void crearAdmin(){
       
        Usuario u =new Usuario(true, "Pedro", "1234");
        listaUsuarios.add(u);
        
    }
    
}
