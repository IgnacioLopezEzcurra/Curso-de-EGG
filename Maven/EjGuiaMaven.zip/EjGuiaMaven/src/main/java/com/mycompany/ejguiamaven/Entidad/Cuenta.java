
package com.mycompany.ejguiamaven.Entidad;


public class Cuenta {
    private Usuario usuario;
    private double saldo;
    private int numCuenta;

    public Cuenta() {
    }

    public Cuenta(Usuario usuario, double saldo, int numCuenta) {
        this.usuario = usuario;
        this.saldo = saldo;
        this.numCuenta = numCuenta;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public int getNumCuenta() {
        return numCuenta;
    }

    public void setNumCuenta(int numCuenta) {
        this.numCuenta = numCuenta;
    }

    
    
}
