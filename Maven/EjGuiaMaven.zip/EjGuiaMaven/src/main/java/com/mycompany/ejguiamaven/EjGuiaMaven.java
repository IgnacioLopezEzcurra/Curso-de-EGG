package com.mycompany.ejguiamaven;

import Servicio.CuentaServicio;
import Servicio.UsuarioServicio;
import com.mycompany.ejguiamaven.Entidad.Usuario;
import java.util.Scanner;

public class EjGuiaMaven {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
        CuentaServicio cs = new CuentaServicio();
        UsuarioServicio us = new UsuarioServicio();
        Usuario u;
        us.crearAdmin();
        int opcion;
        boolean bandera= false;
        do {

            do {
                System.out.println("Ingrese nombre de usuario");
                String nombre = leer.next();
                System.out.println("Ingrese contraseña");
                String contrasena = leer.next();
                u = us.ingresar(contrasena, nombre);

            } while (u == null);

            System.out.println("");

            if (u.isTipo()) {

                do {
                    System.out.println("Seleccione una opcion del menu\n"
                            + "1. Crear nuevo usuario\n"
                            + "2. Salir\n"
                            + "0. Apagar el sistema");
                    opcion = leer.nextInt();
                    switch (opcion) {
                        case 1:
                            us.crearUsuario();
                            break;
                        case 2:
                            System.out.println("Salio del menu");
                            break;
                        case 0:
                            System.out.println("Apago el sistema");
                            bandera = true;
                            opcion =2;
                            break;
                        default:
                            System.out.println("La opcion no existe");
                    }
                } while (opcion != 2);
            } else {

                do {
                    System.out.println("Seleccione una opcion del menu\n"
                            + "1. Crear cuenta\n"
                            + "2. Depositar\n"
                            + "3. Transferir\n"
                            + "4. Retirar\n"
                            + "5. Salir\n"
                            + "0. Apagar el sistema");
                    opcion = leer.nextInt();
                    switch (opcion) {
                        case 1:
                            cs.crearCuenta(u);
                            break;
                        case 2:
                            System.out.println("Ingrese el numero de cuenta");
                            int numCuenta = leer.nextInt();
                            System.out.println("Ingrese el monto a depositar");
                            double monto = leer.nextDouble();
                            cs.depositar(numCuenta, monto);
                            break;
                        case 3:
                            System.out.println("Ingrese el numero de cuenta 1");
                            int numCuenta1 = leer.nextInt();
                            System.out.println("Ingrese el numero de cuenta 2");
                            int numCuenta2 = leer.nextInt();
                            System.out.println("Ingrese el monto a depositar");
                            double montoTrans = leer.nextDouble();
                            cs.tranferencia(numCuenta1, numCuenta2, montoTrans);
                            break;
                        case 4:
                            System.out.println("Ingrese el numero de cuenta");
                            int numCuent = leer.nextInt();
                            System.out.println("Ingrese el monto a retirar");
                            double montoRet = leer.nextDouble();
                            cs.retirar(numCuent, montoRet);
                            break;
                        case 5:
                            System.out.println("Salio del menu");
                            break;
                        case 0:
                            System.out.println("Apago el sistema");
                            bandera = true;
                            opcion=5;
                            break;
                        default:
                            System.out.println("La opcion no existe");
                    }
                } while (opcion != 5);
            }
        } while (!bandera);
    }
}
