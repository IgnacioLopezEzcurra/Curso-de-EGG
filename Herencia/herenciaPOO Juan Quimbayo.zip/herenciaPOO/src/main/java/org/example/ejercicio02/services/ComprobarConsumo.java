package org.example.ejercicio02.services;

public class ComprobarConsumo {



}
