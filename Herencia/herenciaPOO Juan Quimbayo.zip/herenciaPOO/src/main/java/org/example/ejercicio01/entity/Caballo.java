package org.example.ejercicio01.entity;

public class Caballo extends Animal{

	public Caballo(String nombre, String alimento, int edad, String raza) {
		super(nombre, alimento, edad, raza);
	}
}
