/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

public abstract class Integrante {
    protected String nombre;
    protected String Apellido;
    protected String sexo;
    protected String vinculo;
    protected Integer DNI;
    protected Integer nroOrden;
    protected String fechaNac;
    protected ProblemaSalud salud;
    protected AbordajeNutricional nutricion;

    public Integrante() {
    }

    public Integrante(String nombre, String Apellido, String sexo, String vinculo, Integer DNI, Integer nroOrden, String fechaNac, ProblemaSalud salud, AbordajeNutricional nutricion) {
        this.nombre = nombre;
        this.Apellido = Apellido;
        this.sexo = sexo;
        this.vinculo = vinculo;
        this.DNI = DNI;
        this.nroOrden = nroOrden;
        this.fechaNac = fechaNac;
        this.salud = salud;
        this.nutricion = nutricion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getVinculo() {
        return vinculo;
    }

    public void setVinculo(String vinculo) {
        this.vinculo = vinculo;
    }

    public Integer getDNI() {
        return DNI;
    }

    public void setDNI(Integer DNI) {
        this.DNI = DNI;
    }

    public Integer getNroOrden() {
        return nroOrden;
    }

    public void setNroOrden(Integer nroOrden) {
        this.nroOrden = nroOrden;
    }

    public String getFechaNac() {
        return fechaNac;
    }

    public void setFechaNac(String fechaNac) {
        this.fechaNac = fechaNac;
    }

    public ProblemaSalud getSalud() {
        return salud;
    }

    public void setSalud(ProblemaSalud salud) {
        this.salud = salud;
    }

    public AbordajeNutricional getNutricion() {
        return nutricion;
    }

    public void setNutricion(AbordajeNutricional nutricion) {
        this.nutricion = nutricion;
    }
    
    @Override
    public String toString() {
        return "Integrante{" + "nombre=" + nombre + ", Apellido=" + Apellido + ", sexo=" + sexo + ", vinculo=" + vinculo + ", DNI=" + DNI + ", nroOrden=" + nroOrden + ", fechaNac=" + fechaNac + '}';
    }
        
}
