/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

public class Ninio extends Integrante{

    public Ninio(String nombre, String Apellido, String sexo, String vinculo, Integer DNI, Integer nroOrden, String fechaNac, ProblemaSalud salud, AbordajeNutricional nutricion){
        super(nombre, Apellido, sexo, vinculo, DNI, nroOrden, fechaNac, salud, nutricion);
    }
    
}
