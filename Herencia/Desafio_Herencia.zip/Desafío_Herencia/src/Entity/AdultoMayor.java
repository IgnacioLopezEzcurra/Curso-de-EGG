/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

public class AdultoMayor extends Integrante{
    protected boolean jubilacion;

    public AdultoMayor() {
    }

    public AdultoMayor(boolean jubilacion, String nombre, String Apellido, String sexo, String vinculo, Integer DNI, Integer nroOrden, String fechaNac, ProblemaSalud salud, AbordajeNutricional nutricion) {
        super(nombre, Apellido, sexo, vinculo, DNI, nroOrden, fechaNac, salud, nutricion);
        this.jubilacion = jubilacion;
    }

    public boolean isJubilacion() {
        return jubilacion;
    }

    public void setJubilacion(boolean jubilacion) {
        this.jubilacion = jubilacion;
    }

    @Override
    public String toString() {
        return "AdultoMayor{" + "jubilacion=" + jubilacion + '}';
    }
    
}
