/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

public class AbordajeNutricional {
    protected Integer nroOrden;
    protected Integer edad;
    protected Integer peso;
    protected boolean eutrofico;
    protected boolean bajoPeso;
    protected boolean sobrePeso;

    public AbordajeNutricional() {
    }

    public AbordajeNutricional(Integer nroOrden, Integer edad, Integer peso, boolean eutrofico, boolean bajoPeso, boolean sobrePeso) {
        this.nroOrden = nroOrden;
        this.edad = edad;
        this.peso = peso;
        this.eutrofico = eutrofico;
        this.bajoPeso = bajoPeso;
        this.sobrePeso = sobrePeso;
    }

    public Integer getNroOrden() {
        return nroOrden;
    }

    public void setNroOrden(Integer nroOrden) {
        this.nroOrden = nroOrden;
    }

    public Integer getEdad() {
        return edad;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }

    public Integer getPeso() {
        return peso;
    }

    public void setPeso(Integer peso) {
        this.peso = peso;
    }

    public boolean isEutrofico() {
        return eutrofico;
    }

    public void setEutrofico(boolean eutrofico) {
        this.eutrofico = eutrofico;
    }

    public boolean isBajoPeso() {
        return bajoPeso;
    }

    public void setBajoPeso(boolean bajoPeso) {
        this.bajoPeso = bajoPeso;
    }

    public boolean isSobrePeso() {
        return sobrePeso;
    }

    public void setSobrePeso(boolean sobrePeso) {
        this.sobrePeso = sobrePeso;
    }

    @Override
    public String toString() {
        return "AbordajeNutricional{" + "nroOrden=" + nroOrden + ", edad=" + edad + ", peso=" + peso + ", eutrofico=" + eutrofico + ", bajoPeso=" + bajoPeso + ", sobrePeso=" + sobrePeso + '}';
    }
    
}
