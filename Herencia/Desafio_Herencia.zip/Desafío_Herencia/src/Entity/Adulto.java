/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

public class Adulto extends Integrante{
    protected boolean estudio;
    protected boolean trabForm;
    protected boolean obraSocial;
    protected boolean deporte;

    public Adulto() {
    }

    public Adulto(boolean estudio, boolean trabForm, boolean obraSocial, boolean deporte, String nombre, String Apellido, String sexo, String vinculo, Integer DNI, Integer nroOrden, String fechaNac, ProblemaSalud salud, AbordajeNutricional nutricion) {
        super(nombre, Apellido, sexo, vinculo, DNI, nroOrden, fechaNac, salud, nutricion);
        this.estudio = estudio;
        this.trabForm = trabForm;
        this.obraSocial = obraSocial;
        this.deporte = deporte;
    }

    public boolean isEstudio() {
        return estudio;
    }

    public void setEstudio(boolean estudio) {
        this.estudio = estudio;
    }

    public boolean isTrabForm() {
        return trabForm;
    }

    public void setTrabForm(boolean trabForm) {
        this.trabForm = trabForm;
    }

    public boolean isObraSocial() {
        return obraSocial;
    }

    public void setObraSocial(boolean obraSocial) {
        this.obraSocial = obraSocial;
    }

    public boolean isDeporte() {
        return deporte;
    }

    public void setDeporte(boolean deporte) {
        this.deporte = deporte;
    }

    @Override
    public String toString() {
        return "Adulto{" + "estudio=" + estudio + ", trabForm=" + trabForm + ", obraSocial=" + obraSocial + ", deporte=" + deporte + '}';
    }
    
}
