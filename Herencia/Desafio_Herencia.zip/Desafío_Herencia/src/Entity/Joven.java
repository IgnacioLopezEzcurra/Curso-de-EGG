/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

public class Joven extends Integrante {
    protected String estudio;
    protected boolean deporte;
    protected boolean trabajo;

    public Joven() {
    }

    public Joven(String nombre, String Apellido, String sexo, String vinculo, Integer DNI, Integer nroOrden, String fechaNac, ProblemaSalud salud, AbordajeNutricional nutricion, String estudio, boolean deporte, boolean trabajo) {
        super(nombre, Apellido, sexo, vinculo, DNI, nroOrden, fechaNac, salud, nutricion);
        this.estudio = estudio;
        this.deporte = deporte;
        this.trabajo = trabajo;
    }

    public String getEstudio() {
        return estudio;
    }

    public void setEstudio(String estudio) {
        this.estudio = estudio;
    }

    public boolean isDeporte() {
        return deporte;
    }

    public void setDeporte(boolean deporte) {
        this.deporte = deporte;
    }

    public boolean isTrabajo() {
        return trabajo;
    }

    public void setTrabajo(boolean trabajo) {
        this.trabajo = trabajo;
    }

    @Override
    public String toString() {
        return "Joven{" + "estudio=" + estudio + ", deporte=" + deporte + ", trabajo=" + trabajo + '}';
    }
    
}
