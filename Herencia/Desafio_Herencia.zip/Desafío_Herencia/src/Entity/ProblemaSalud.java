/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

public class ProblemaSalud {
       protected Integer nroOrden;
       protected Integer IDE;
       protected boolean HTA;
       protected boolean DBT;

    public ProblemaSalud() {
    }

    public ProblemaSalud(Integer nroOrden, Integer IDE, boolean HTA, boolean DBT) {
        this.nroOrden = nroOrden;
        this.IDE = IDE;
        this.HTA = HTA;
        this.DBT = DBT;
    }

    public Integer getNroOrden() {
        return nroOrden;
    }

    public void setNroOrden(Integer nroOrden) {
        this.nroOrden = nroOrden;
    }

    public Integer getIDE() {
        return IDE;
    }

    public void setIDE(Integer IDE) {
        this.IDE = IDE;
    }

    public boolean isHTA() {
        return HTA;
    }

    public void setHTA(boolean HTA) {
        this.HTA = HTA;
    }

    public boolean isDBT() {
        return DBT;
    }

    public void setDBT(boolean DBT) {
        this.DBT = DBT;
    }

    @Override
    public String toString() {
        return "ProblemaSalud{" + "nroOrden=" + nroOrden + ", IDE=" + IDE + ", HTA=" + HTA + ", DBT=" + DBT + '}';
    }
       
}
