/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.util.ArrayList;

public class Familia {
    protected String direccion;
    protected Integer IDE;
    protected Integer nroLote;
    protected String barrio;
    protected String localidad;
    protected boolean mejora;
    protected ArrayList factorRiesgo;
    protected ArrayList<Integrante> integrantes;

    public Familia() {
    }

    public Familia(String direccion, Integer IDE, Integer nroLote, String barrio, String localidad, boolean mejora, ArrayList factorRiesgo, ArrayList<Integrante> integrantes) {
        this.direccion = direccion;
        this.IDE = IDE;
        this.nroLote = nroLote;
        this.barrio = barrio;
        this.localidad = localidad;
        this.mejora = mejora;
        this.factorRiesgo = factorRiesgo;
        this.integrantes = integrantes;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Integer getIDE() {
        return IDE;
    }

    public void setIDE(Integer IDE) {
        this.IDE = IDE;
    }

    public Integer getNroLote() {
        return nroLote;
    }

    public void setNroLote(Integer nroLote) {
        this.nroLote = nroLote;
    }

    public String getBarrio() {
        return barrio;
    }

    public void setBarrio(String barrio) {
        this.barrio = barrio;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public boolean isMejora() {
        return mejora;
    }

    public void setMejora(boolean mejora) {
        this.mejora = mejora;
    }

    public ArrayList getFactorRiesgo() {
        return factorRiesgo;
    }

    public void setFactorRiesgo(ArrayList factorRiesgo) {
        this.factorRiesgo = factorRiesgo;
    }

    public ArrayList<Integrante> getIntegrantes() {
        return integrantes;
    }

    public void setIntegrantes(ArrayList<Integrante> integrantes) {
        this.integrantes = integrantes;
    }

    @Override
    public String toString() {
        return "Familia{" + "direccion=" + direccion + ", IDE=" + IDE + ", nroLote=" + nroLote + ", barrio=" + barrio + ", localidad=" + localidad + ", mejora=" + mejora + ", factorRiesgo=" + factorRiesgo + ", integrantes=" + integrantes + '}';
    }
    
}
